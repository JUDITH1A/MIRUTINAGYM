Instrucciones para MIRUTINAGYM (versión debug - MiRutina.apk)
=============================================================

📦 Qué incluye este ZIP:
- app/google-services.json (tu configuración Firebase)
- .github/workflows/compilación.yml (workflow automático)

🚀 Cómo usarlo desde tu celular:
1️⃣ Abre tu repositorio en GitHub: https://github.com/JUDITH1A/MIRUTINAGYM
2️⃣ Toca "Add file" → "Upload files"
3️⃣ Sube este archivo ZIP (o descomprímelo y sube las carpetas)
4️⃣ Confirma "Commit changes" en la rama main
5️⃣ Abre la pestaña Actions → espera la compilación
6️⃣ Descarga el APK desde "Artifacts" → "MiRutina-APK" → MiRutina.apk

📱 Resultado:
- APK compilado automáticamente (versión debug)
- Nombre del archivo: MiRutina.apk
