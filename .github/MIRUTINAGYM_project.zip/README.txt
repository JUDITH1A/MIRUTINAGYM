MIRUTINAGYM minimal project for Judy.
